
QMap<QString, int> your_stocks;
QMap<QString, int> your_crypto_holdings;
QMap<QString, QPair<int, int>> your_property_holdings;
QMap<QString, int> days_owned ;
float bank_balance = 10000 ;
QStringList newsArray ;
int DAY_NUMBER = 0 ;
int randomIndex;  // To track the news index
QString newsText;
int jugad ;
QString selectedNews;
int indexes_of_companies[4]={0,0,0,0};
float total_loan_taken = 0.0 ;
float net_balance ;
int loan_number = 0 ;
bool change_occured ;
QList<float> previous_stock_prices;
QList<float> final_stock_prices;
QList<bool> colour ;
int countries_at_war_with = 0 ;
int balancia ;
int country_health = 75 ;
float war_impact = 0.02 ;
float overall_change_internal_chaos = 0.0f;
bool negative_news = false ;
int reputation = 50 ;
int arrestProbability = 0; // Default probability
int number_of_petitions = 0 ; // Starts at 1 petition filed
int LAWYER=10000;

